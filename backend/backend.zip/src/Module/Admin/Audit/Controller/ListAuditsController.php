<?php

declare(strict_types=1);

namespace App\Module\Admin\Audit\Controller;

use App\Module\Audit\Repository\AuditRequestRepository;
use App\Shared\Http\ApiResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/api/admin/audits', name: 'api_admin_audits_list', methods: ['GET'])]
#[IsGranted('ROLE_ADMIN')]
class ListAuditsController extends AbstractController
{
    public function __construct(private readonly AuditRequestRepository $repository) {}

    public function __invoke(): JsonResponse
    {
        $items = $this->repository->findBy([], ['createdAt' => 'DESC']);
        return ApiResponse::success([
            'items' => array_map(static function($a) {
                return [
                    'id' => $a->getId(),
                    'number' => $a->getNumber(),
                    'type' => $a->getType()->value,
                    'status' => $a->getStatus(),
                    'url' => $a->getTargetUrl(),
                    'client' => [
                        'id' => $a->getClient()->getId(),
                        'name' => $a->getClient()->getFullName(),
                        'email' => $a->getClient()->getEmail(),
                    ],
                    'createdAt' => $a->getCreatedAt()->format(DATE_ATOM),
                ];
            }, $items),
        ]);
    }
}

