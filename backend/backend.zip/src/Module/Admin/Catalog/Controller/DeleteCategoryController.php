<?php

declare(strict_types=1);

namespace App\Module\Admin\Catalog\Controller;

use App\Module\Catalog\Repository\CategoryRepository;
use App\Module\Catalog\Service\CategoryService;
use App\Shared\Http\ApiResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;
use Throwable;

#[Route('/api/admin/catalog/categories/{id}', name: 'api_admin_catalog_categories_delete', methods: ['DELETE'])]
#[IsGranted('ROLE_ADMIN')]
class DeleteCategoryController extends AbstractController
{
    public function __construct(
        private readonly CategoryRepository $categoryRepository,
        private readonly CategoryService $categoryService,
    ) {
    }

    public function __invoke(int $id): JsonResponse
    {
        $category = $this->categoryRepository->find($id);

        if ($category === null) {
            return ApiResponse::error('Categorie introuvable.', Response::HTTP_NOT_FOUND);
        }

        try {
            $this->categoryService->delete($category);
        } catch (Throwable $exception) {
            return ApiResponse::error(
                'Impossible de supprimer la categorie.',
                Response::HTTP_BAD_REQUEST,
                [$exception->getMessage()]
            );
        }

        return ApiResponse::success(['id' => $id]);
    }
}



