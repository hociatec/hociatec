<?php

declare(strict_types=1);

namespace App\Module\User\Controller\Address;

use App\Module\User\Entity\User;
use App\Module\User\Repository\ShippingAddressRepository;
use App\Shared\Http\ApiResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Security\Http\Attribute\IsGranted;

#[Route('/api/addresses/{id}/default', name: 'api_addresses_set_default', requirements: ['id' => '\\d+'], methods: ['PUT'])]
#[IsGranted('ROLE_USER')]
class SetDefaultAddressController extends AbstractController
{
    public function __construct(private readonly ShippingAddressRepository $addresses) {}

    public function __invoke(int $id): JsonResponse
    {
        /** @var User $user */
        $user = $this->getUser();
        $address = $this->addresses->findOneForUser($id, $user);
        if ($address === null) {
            return ApiResponse::error('Adresse introuvable.', JsonResponse::HTTP_NOT_FOUND);
        }

        $this->addresses->setDefault($user, $address);
        return ApiResponse::success(['message' => 'Adresse définie par défaut']);
    }
}

