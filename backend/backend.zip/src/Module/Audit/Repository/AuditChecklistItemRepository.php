<?php

declare(strict_types=1);

namespace App\Module\Audit\Repository;

use App\Module\Audit\Entity\AuditChecklistItem;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<AuditChecklistItem>
 */
class AuditChecklistItemRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, AuditChecklistItem::class);
    }
}

