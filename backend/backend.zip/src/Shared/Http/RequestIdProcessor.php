<?php

declare(strict_types=1);

namespace App\Shared\Http;

use Monolog\LogRecord;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorageInterface;

final class RequestIdProcessor
{
    public function __construct(
        private readonly RequestStack $requestStack,
        private readonly ?TokenStorageInterface $tokenStorage = null,
    ) {
    }

    /**
     * Monolog v3 signature.
     */
    public function __invoke(LogRecord $record): LogRecord
    {
        $request = $this->requestStack->getCurrentRequest();
        if ($request === null) {
            return $record;
        }

        $ctx = $record->context;
        $ctx['request_id'] = (string) ($request->attributes->get(RequestIdSubscriber::ATTRIBUTE) ?? '');
        $ctx['method'] = $request->getMethod();
        $ctx['path'] = $request->getPathInfo();
        $ctx['ip'] = $request->getClientIp();
        $ctx['route'] = (string) ($request->attributes->get('_route') ?? '');

        if ($this->tokenStorage !== null && ($token = $this->tokenStorage->getToken())) {
            $user = $token->getUser();
            if (\is_object($user) && \method_exists($user, 'getId')) {
                $ctx['user_id'] = $user->getId();
            }
        }

        return $record->with(context: $ctx);
    }
}
